import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription, GroupAction, ExecuteProcess, TimerAction
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.actions import Node, SetRemap


def generate_launch_description():
    pkg_share = get_package_share_directory('go2_nav_slam_sim')
    params_file = os.path.join(pkg_share, 'config', 'go2_nav_localization.yaml')
    rviz_config = os.path.join(pkg_share, 'rviz', 'go2_nav_slam_sim.rviz')

    # path saved map
    map_file = '/home/lorenzo/go2_haptic_teleop_ws/src/go2_nav_slam_sim/maps/warehouse.yaml'

    ground_truth_bridge = Node(
        package='go2_nav_slam_sim',
        executable='ground_truth_to_tf',
        name='ground_truth_to_tf',
        output='screen',
        parameters=[{
            'input_topic': '/odom/ground_truth',
            'odom_frame': 'odom',
            'base_frame': 'base_link'
        }]
    )

    pointcloud_to_scan = Node(
        package='pointcloud_to_laserscan',
        executable='pointcloud_to_laserscan_node',
        name='pointcloud_to_laserscan',
        output='screen',
        parameters=[{
            'target_frame': 'base_link',
            'transform_tolerance': 0.10,
            'min_height': -0.15,
            'max_height': 0.30,
            'angle_min': -3.14159,
            'angle_max': 3.14159,
            'angle_increment': 0.0087,
            'scan_time': 0.1,
            'range_min': 0.15,
            'range_max': 20.0,
            'use_inf': True,
            'inf_epsilon': 1.0,
            'queue_size': 8
        }],
        remappings=[
            ('cloud_in', '/velodyne_points'),
            ('scan', '/scan_raw')
        ]
    )

    nav2_bringup = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(
                get_package_share_directory('nav2_bringup'),
                'launch',
                'bringup_launch.py'
            )
        ),
        launch_arguments={
            'slam': 'False',
            'map': map_file,
            'use_sim_time': 'True',
            'params_file': params_file,
            'autostart': 'True',
            'use_composition': 'False'
        }.items()
    )

    nav2_group = GroupAction([
        SetRemap(src='/scan', dst='/scan_raw'),
        nav2_bringup
    ])

    configure_activate_map_server = TimerAction(
        period=3.0,
        actions=[
            ExecuteProcess(
                cmd=['ros2', 'lifecycle', 'set', '/map_server', 'configure'],
                output='screen'
            ),
            ExecuteProcess(
                cmd=['ros2', 'lifecycle', 'set', '/map_server', 'activate'],
                output='screen'
            ),
        ]
    )

    configure_activate_amcl = TimerAction(
        period=5.0,
        actions=[
            ExecuteProcess(
                cmd=['ros2', 'lifecycle', 'set', '/amcl', 'configure'],
                output='screen'
            ),
            ExecuteProcess(
                cmd=['ros2', 'lifecycle', 'set', '/amcl', 'activate'],
                output='screen'
            ),
        ]
    )

    configure_activate_nav = TimerAction(
        period=7.0,
        actions=[
            ExecuteProcess(
                cmd=['ros2', 'lifecycle', 'set', '/planner_server', 'configure'],
                output='screen'
            ),
            ExecuteProcess(
                cmd=['ros2', 'lifecycle', 'set', '/planner_server', 'activate'],
                output='screen'
            ),
            ExecuteProcess(
                cmd=['ros2', 'lifecycle', 'set', '/controller_server', 'configure'],
                output='screen'
            ),
            ExecuteProcess(
                cmd=['ros2', 'lifecycle', 'set', '/controller_server', 'activate'],
                output='screen'
            ),
            ExecuteProcess(
                cmd=['ros2', 'lifecycle', 'set', '/bt_navigator', 'configure'],
                output='screen'
            ),
            ExecuteProcess(
                cmd=['ros2', 'lifecycle', 'set', '/bt_navigator', 'activate'],
                output='screen'
            ),
            ExecuteProcess(
                cmd=['ros2', 'lifecycle', 'set', '/behavior_server', 'configure'],
                output='screen'
            ),
            ExecuteProcess(
                cmd=['ros2', 'lifecycle', 'set', '/behavior_server', 'activate'],
                output='screen'
            ),
            ExecuteProcess(
                cmd=['ros2', 'lifecycle', 'set', '/smoother_server', 'configure'],
                output='screen'
            ),
            ExecuteProcess(
                cmd=['ros2', 'lifecycle', 'set', '/smoother_server', 'activate'],
                output='screen'
            ),
            ExecuteProcess(
                cmd=['ros2', 'lifecycle', 'set', '/velocity_smoother', 'configure'],
                output='screen'
            ),
            ExecuteProcess(
                cmd=['ros2', 'lifecycle', 'set', '/velocity_smoother', 'activate'],
                output='screen'
            ),
            ExecuteProcess(
                cmd=['ros2', 'lifecycle', 'set', '/waypoint_follower', 'configure'],
                output='screen'
            ),
            ExecuteProcess(
                cmd=['ros2', 'lifecycle', 'set', '/waypoint_follower', 'activate'],
                output='screen'
            ),
        ]
    )
    rviz = TimerAction(
        period=10.0,
        actions=[
            Node(
                package='rviz2',
                executable='rviz2',
                name='rviz2',
                output='screen',
                arguments=['-d', rviz_config]
            )
        ]
    )

    refresh_map_for_rviz = TimerAction(
        period=13.0,
        actions=[
            ExecuteProcess(
                cmd=['ros2', 'lifecycle', 'set', '/map_server', 'deactivate'],
                output='screen'
            ),
            ExecuteProcess(
                cmd=['ros2', 'lifecycle', 'set', '/map_server', 'activate'],
                output='screen'
            ),
        ]
    )

    return LaunchDescription([
        ground_truth_bridge,
        pointcloud_to_scan,
        nav2_group,
        rviz,
        configure_activate_map_server,
        configure_activate_amcl,
        configure_activate_nav,
        refresh_map_for_rviz
    ])